import React from "react";
import DonateItems from "./Donor/DonateItems"; // Ensure this file exists in the correct path
import TrackResources from "./Donor/TrackResources"; // Ensure this file exists in the correct path
import ChatSection from "./Donor/ChatSection"; // Ensure this file exists in the correct path
import DonateMoney from "./Donor/DonateMoney"; // Ensure this file exists in the correct path
import { useNavigate } from "react-router-dom";

const DonorPage = () => {
  const navigate = useNavigate();
  const handleChatClick = () => {
    navigate('/chat');
  };

  return (
    <div className="container mx-auto p-6 bg-gradient-to-b from-blue-100 via-white to-green-100 min-h-screen">
      <h1 className="text-4xl font-bold text-center mb-8 text-gray-800">Donor Dashboard</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="p-6 border rounded-lg shadow-lg bg-white">
          <DonateMoney />
        </div>
        <div className="p-6 border rounded-lg shadow-lg bg-white">
          <DonateItems />
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-6">
        <div className="p-6 border rounded-lg shadow-lg bg-white">
          <TrackResources />
        </div>
        <div className="p-6 border rounded-lg shadow-lg bg-white">
          <ChatSection />
        </div>
      </div>
      <button
        onClick={handleChatClick}
        className="bg-blue-600 text-white px-6 py-2 rounded-md w-48 mt-8 flex items-center justify-center hover:bg-blue-700 mx-auto"
      >
        Chat
      </button>
    </div>
  );
};

export default DonorPage;
