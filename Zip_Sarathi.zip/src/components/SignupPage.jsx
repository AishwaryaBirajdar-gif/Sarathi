import React from "react";

const SignupPage = () => {
  return (
    <div className="h-screen flex items-center justify-center bg-gradient-to-b from-indigo-500 to-purple-700">
      <div className="w-full max-w-md bg-white rounded-lg shadow-lg p-8 transform hover:scale-105 transition-transform duration-500">
        <h2 className="text-3xl font-bold text-center text-purple-800 mb-6">
          Create Account
        </h2>
        <p className="text-center text-gray-600 mb-6">
          Join SARATHI and be a part of making a difference!
        </p>
        <form className="mt-6">
          {/* Full Name Input */}
          <div className="mb-4">
            <label htmlFor="name" className="block text-purple-700 font-medium">
              Full Name
            </label>
            <input
              type="text"
              id="name"
              name="name"
              placeholder="Enter your full name"
              className="w-full mt-2 p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring focus:ring-purple-300 transition duration-300"
              required
            />
          </div>

          {/* Email Input */}
          <div className="mb-4">
            <label htmlFor="email" className="block text-purple-700 font-medium">
              Email Address
            </label>
            <input
              type="email"
              id="email"
              name="email"
              placeholder="Enter your email"
              className="w-full mt-2 p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring focus:ring-purple-300 transition duration-300"
              required
            />
          </div>

          {/* Password Input */}
          <div className="mb-6">
            <label htmlFor="password" className="block text-purple-700 font-medium">
              Password
            </label>
            <input
              type="password"
              id="password"
              name="password"
              placeholder="Enter your password"
              className="w-full mt-2 p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring focus:ring-purple-300 transition duration-300"
              required
            />
          </div>

          {/* Signup Button */}
          <button
            type="submit"
            className="w-full bg-gradient-to-r from-purple-600 to-indigo-500 text-white font-semibold py-3 rounded-lg hover:from-purple-700 hover:to-indigo-600 transition duration-300 transform hover:scale-105"
          >
            Sign Up
          </button>
        </form>

        {/* Already Have Account */}
        <p className="mt-6 text-sm text-center text-gray-600">
          Already have an account?{" "}
          <a
            href="/login"
            className="text-purple-600 hover:underline hover:text-purple-800 transition duration-300"
          >
            Log In
          </a>
        </p>
      </div>
    </div>
  );
};

export default SignupPage;
