import React from 'react'

const VolunteerPage = () => {
  return (
    <div>VolunteerPage</div>
  )
}

export default VolunteerPage